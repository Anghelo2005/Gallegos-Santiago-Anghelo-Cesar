<?php

use App\Models\Actividad;
use App\Models\Especie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ActividadController;
use App\Http\Controllers\AnimalController;
use App\Http\Controllers\EspecieController;
use App\Http\Controllers\CuidadorController;
use App\Http\Controllers\RecintoController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('Actividad',[ActividadController::class,'index']);
Route::get('Actividades/{id}',[ActividadController::class,'show']);
Route::post('Actividad',[ActividadController::class,'store']);
Route::patch('Actividad/{id}',[ActividadController::class,'update']);
Route::delete('Actividad/{id}',[ActividadController::class,'destroy']);

Route::get('Animal',[AnimalController::class,'index']);
Route::get('Animal/{id}',[AnimalController::class,'show']);
Route::post('Animal',[AnimalController::class,'store']);
Route::patch('Animal/{id}',[AnimalController::class,'update']);
Route::delete('Animal/{id}',[AnimalController::class,'destroy']);

Route::get('Especie',[EspecieController::class,'index']);
Route::get('Especie/{id}',[EspecieController::class,'show']);
Route::post('Especie',[EspecieController::class,'store']);
Route::patch('Especie/{id}',[EspecieController::class,'update']);
Route::delete('Especie/{id}',[EspecieController::class,'destroy']);

Route::get('Cuidador',[CuidadorController::class,'index']);
Route::get('Cuidador/{id}',[CuidadorController::class,'show']);
Route::post('Cuidador',[CuidadorController::class,'store']);
Route::patch('Cuidador/{id}',[CuidadorController::class,'update']);
Route::delete('Cuidador/{id}',[CuidadorController::class,'destroy']);

Route::get('Recinto',[RecintoController::class,'index']);
Route::get('Recinto/{id}',[RecintoController::class,'show']);
Route::post('Recinto',[RecintoController::class,'store']);
Route::patch('Recinto/{id}',[RecintoController::class,'update']);
Route::delete('Recinto/{id}',[RecintoController::class,'destroy']);
