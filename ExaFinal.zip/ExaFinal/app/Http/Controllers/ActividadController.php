<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Actividad;

class ActividadController extends Controller
{
   public function store(request $request)
   {
        $params = $request->all();
        $Actividad=Actividad::create([
            'dia'=>$params['dia'],
            'horario'=>$params['dia'],
            'animales_Asociados'=>$params['dia']
        ]);
        return $Actividad;
    }
    public function index(request $request)
    {
         $params = $request->all();
         $size =isser($params['size'])?$params['size']:5;
         $Actividades=Actividad::where('dia','>=',$params['dia'])
         ->ger()->limit($params['size']);
         return $Actividades;
     }

    public function show( $id)
    {
         $actividad=Actividad::find($id);
         return $Actividad;
     }
     public function update($id,request $request)
     {
        $params = $request->all();
         $actividad=actividad::find($id)->update([
            'dia'=>$params['dia'],
            'horario'=>$params['dia'],
            'animales_Asociados'=>$params['dia'],
         ]);
          return 'Datos actualizados';

      }
      public function destroy($id)
      {
          $actividad=actividad::find($id)->delete();

           return 'Datos eliminados';
       }
};
