<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Recinto;

class RecintoController extends Controller
{
    public function store(request $request)
    {
         $params = $request->all();
         $Recinto=Recinto::create([
             'nombre'=>$params['nombre'],
             'id_animales'=>$params['animales'],
         ]);
         return $Recinto;
     }
     public function index(request $request)
     {
          $params = $request->all();
          $size =isset($params['size'])?$params['size']:5;
          $Recinto=Recinto::where('nombre','>=',$params['nombre'])
          ->ger()->limit($params['size']);
          return $Recinto;
      }

     public function show( $id)
     {
          $Recinto=Recinto::find($id);
          return $Recinto;
      }
      public function update($id,request $request)
      {
         $params = $request->all();
          $Recinto=Recinto::find($id)->update([
            'nombre'=>$params['nombre'],
            'id_animales'=>$params['animales'],
          ]);
           return 'Datos actualizados';

       }
       public function destroy($id)
       {
           $Recinto=Recinto::find($id)->delete();

            return 'Datos eliminados';
        }
 };
